This Jupyter Notebook demonstrates a workflow for multi-target time series forecasting using a custom neural network model implemented in PyTorch. The workflow includes data loading, preprocessing, feature engineering, normalization, model training, prediction, and visualization of forecast percentiles.

## Contents

- **Import Libraries**: Essential libraries for data manipulation, machine learning, and neural networks are imported, including `pandas`, `numpy`, `sklearn`, `torch`, and others.
- **Neural Network Definition**: The `Neural_Predictor` class defines a feedforward neural network for multi-target regression, with dropout for regularization.
- **Loss Function**: A mean squared error loss function is defined for model training.
- **Predictor Class**: The `Predictor` class encapsulates the entire forecasting pipeline:
    - Data loading from parquet files
    - Lagged feature creation
    - Data cleaning (NaN and duplicate removal)
    - Feature/target separation
    - Data normalization
    - Covariance calculation for targets
    - Model training with PyTorch
    - Scenario-based prediction generation
    - Visualization of prediction percentiles
- **Workflow Example**: An instance of `Predictor` is created and the full pipeline is executed, including reading data, preprocessing, training, prediction, and plotting.

## Usage

1. **Prepare Data**: Place your training and testing data in the `data/` directory as parquet files.
2. **Run the Notebook**: Execute each cell in order. The pipeline will:
     - Load and preprocess the data
     - Train a neural network on the training set
     - Generate probabilistic forecasts for multiple scenarios
     - Visualize the 5th, 50th, and 95th percentiles of the predictions for each target variable

## Output

- **Predictions**: Scenario-based predictions are saved as CSV files.
- **Plots**: Percentile plots for each target variable are saved as PNG images.

## Requirements

- Python 3.x
- pandas
- numpy
- scikit-learn
- torch
- matplotlib
- seaborn
- skforecast

## Notes

- The neural network architecture and hyperparameters can be adjusted in the `Neural_Predictor` class.
- The number of scenarios for probabilistic forecasting is set by `num_scenario` in the `Predictor` class.
- The code is modular and can be adapted for other multi-target time series forecasting tasks.

---